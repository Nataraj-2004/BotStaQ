import { Request, Response } from "express";
import { db } from "../data/mockStore.js";

export function getDashboardSummary(_req: Request, res: Response): void {
  const stats = db.getDashboardSummary();
  res.json(stats);
}
