import { Request, Response } from "express";

export function refundInvoice(req: Request, res: Response): void {
  const { id } = req.params;
  const { amount } = req.body ?? {};
  res.json({
    status: "pending_refund",
    invoiceId: id,
    amount,
    processedBy: req.user?.id,
  });
}
