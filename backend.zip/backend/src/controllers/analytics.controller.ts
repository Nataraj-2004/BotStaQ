import { Request, Response } from "express";
import { db } from "../data/mockStore.js";

export function exportAnalytics(req: Request, res: Response): void {
  const { range = "last_30_days" } = req.body ?? {};
  res.json({
    status: "exporting",
    range,
    tenant_id: req.user?.tenant_id,
  });
}

export function getAnalyticsOverview(req: Request, res: Response): void {
  const { range = "month" } = req.query;
  const overview = db.getAnalytics(String(range));
  res.json(overview);
}
