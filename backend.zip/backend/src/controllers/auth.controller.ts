import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/env.js";

export function login(req: Request, res: Response): void {
  const { email } = req.body ?? {};
  if (!email) {
    res.status(400).json({ error: "email is required" });
    return;
  }

  const payload = {
    sub: "user-1",
    id: "user-1",
    email,
    tenant_id: "tenant-demo",
    roles: ["company_admin"],
    direct_permissions: [],
  };

  const token = jwt.sign(payload, env.JWT_SECRET, { expiresIn: "1h" });
  res.json({
    token,
    user: {
      id: payload.id,
      email: payload.email,
      roles: payload.roles,
      tenant_id: payload.tenant_id,
    },
  });
}
