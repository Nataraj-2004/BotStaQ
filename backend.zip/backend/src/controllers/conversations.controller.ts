import { Request, Response } from "express";
import { db } from "../data/mockStore.js";
import type { Message } from "../types/domain.js";

export function listConversations(_req: Request, res: Response): void {
  res.json(db.conversations);
}

export function listMessages(req: Request, res: Response): void {
  const { id } = req.params;
  const exists = db.conversations.some((conversation) => conversation.id === id);
  if (!exists) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const messages = db.messages.filter((message) => message.conversationId === id);
  res.json(messages);
}

export function postMessage(req: Request, res: Response): void {
  const { id } = req.params;
  const { text, sender } = req.body ?? {};
  if (!text) {
    res.status(400).json({ error: "text is required" });
    return;
  }
  const allowedSenders: Message["sender"][] = ["user", "agent", "bot"];
  const normalizedSender: Message["sender"] = allowedSenders.includes(sender)
    ? sender
    : "agent";
  const message = db.addMessage(id, normalizedSender, text);
  res.status(201).json(message);
}

export function assignConversation(req: Request, res: Response): void {
  const { id } = req.params;
  const { assignee } = req.body ?? {};
  const conversation = db.conversations.find((item) => item.id === id);
  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  conversation.assignee = assignee ?? req.user?.id ?? conversation.assignee;
  res.json(conversation);
}

export function takeoverConversation(req: Request, res: Response): void {
  const { conversationId } = req.params;
  res.json({
    status: "ok",
    action: "chat.takeover",
    conversationId,
    takenBy: req.user?.id,
  });
}
