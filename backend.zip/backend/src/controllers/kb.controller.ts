import { Request, Response } from "express";
import { db } from "../data/mockStore.js";

export function listKnowledgeBase(_req: Request, res: Response): void {
  res.json(db.listKnowledgeBase());
}

export function createDocument(req: Request, res: Response): void {
  const { title } = req.body ?? {};
  if (!title) {
    res.status(400).json({ error: "title is required" });
    return;
  }
  const doc = db.addKnowledgeDocument(title);
  res.status(201).json(doc);
}

export function createFaq(req: Request, res: Response): void {
  const { question, answer } = req.body ?? {};
  if (!question || !answer) {
    res.status(400).json({ error: "question and answer are required" });
    return;
  }
  const faq = db.addFaq(question, answer);
  res.status(201).json(faq);
}

export function createRule(req: Request, res: Response): void {
  const { name, trigger } = req.body ?? {};
  if (!name || !trigger) {
    res.status(400).json({ error: "name and trigger are required" });
    return;
  }
  const rule = db.addRule(name, trigger);
  res.status(201).json(rule);
}

export function createProduct(req: Request, res: Response): void {
  const { name, price, plan } = req.body ?? {};
  if (!name || typeof price !== "number" || !plan) {
    res.status(400).json({ error: "name, price, and plan are required" });
    return;
  }
  const product = db.addProduct(name, price, plan);
  res.status(201).json(product);
}
