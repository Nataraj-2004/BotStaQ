import { Request, Response } from "express";
import { db } from "../data/mockStore.js";

export function listLeads(_req: Request, res: Response): void {
  res.json(db.leads);
}

export function createLead(req: Request, res: Response): void {
  const { name, email, stage, source, score, owner } = req.body ?? {};
  if (!name) {
    res.status(400).json({ error: "name is required" });
    return;
  }
  const lead = db.addLead({ name, email, stage, source, score, owner });
  res.status(201).json(lead);
}

export function updateLead(req: Request, res: Response): void {
  const { id } = req.params;
  const lead = db.updateLead(id, req.body ?? {});
  if (!lead) {
    res.status(404).json({ error: "Lead not found" });
    return;
  }
  res.json(lead);
}

export function mergeLeads(req: Request, res: Response): void {
  const { primaryId, duplicateId } = req.body ?? {};
  if (!primaryId || !duplicateId) {
    res.status(400).json({ error: "primaryId and duplicateId are required" });
    return;
  }
  const primary = db.leads.find((lead) => lead.id === primaryId);
  const duplicateIndex = db.leads.findIndex((lead) => lead.id === duplicateId);
  if (!primary || duplicateIndex === -1) {
    res.status(404).json({ error: "Leads not found" });
    return;
  }
  const duplicate = db.leads[duplicateIndex];
  db.leads.splice(duplicateIndex, 1);
  const merged = db.updateLead(primaryId, {
    email: primary.email ?? duplicate.email,
    source: primary.source ?? duplicate.source,
    score: Math.max(primary.score ?? 0, duplicate.score ?? 0),
  });
  res.json({ mergedLead: merged, removedLeadId: duplicate.id });
}
