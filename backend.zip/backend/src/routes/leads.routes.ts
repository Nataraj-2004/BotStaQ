import { Router } from "express";
import { createLead, listLeads, mergeLeads, updateLead } from "../controllers/leads.controller.js";
import { authenticate } from "../middlewares/auth.guard.js";
import { requireAction } from "../middlewares/requireAction.js";

const router = Router();

router.get(
  "/",
  authenticate,
  requireAction("lead.view", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "lead_collection" }),
  }),
  listLeads
);

router.post(
  "/",
  authenticate,
  requireAction("lead.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "lead" }),
  }),
  createLead
);

router.patch(
  "/:id",
  authenticate,
  requireAction("lead.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "lead", id: req.params.id }),
  }),
  updateLead
);

router.post(
  "/merge",
  authenticate,
  requireAction("lead.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "lead_merge" }),
  }),
  mergeLeads
);

export default router;
