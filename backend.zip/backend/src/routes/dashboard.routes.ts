import { Router } from "express";
import { getDashboardSummary } from "../controllers/dashboard.controller.js";
import { authenticate } from "../middlewares/auth.guard.js";
import { requireAction } from "../middlewares/requireAction.js";

const router = Router();

router.get(
  "/summary",
  authenticate,
  requireAction("analytics.read", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "dashboard" }),
  }),
  getDashboardSummary
);

export default router;
