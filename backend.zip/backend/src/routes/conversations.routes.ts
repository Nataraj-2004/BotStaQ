import { Router } from "express";
import {
  assignConversation,
  listConversations,
  listMessages,
  postMessage,
  takeoverConversation,
} from "../controllers/conversations.controller.js";
import { authenticate } from "../middlewares/auth.guard.js";
import { requireAction } from "../middlewares/requireAction.js";

const router = Router();

router.get(
  "/",
  authenticate,
  requireAction("chat.view", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "conversation_list" }),
  }),
  listConversations
);

router.get(
  "/:id/messages",
  authenticate,
  requireAction("chat.view", {
    resource: (req) => ({
      tenant_id: req.user!.tenant_id,
      type: "conversation",
      id: req.params.id,
    }),
  }),
  listMessages
);

router.post(
  "/:id/messages",
  authenticate,
  requireAction("chat.takeover", {
    resource: (req) => ({
      tenant_id: req.user!.tenant_id,
      type: "conversation",
      id: req.params.id,
    }),
  }),
  postMessage
);

router.post(
  "/:id/assign",
  authenticate,
  requireAction("chat.takeover", {
    resource: (req) => ({
      tenant_id: req.user!.tenant_id,
      type: "conversation",
      id: req.params.id,
    }),
  }),
  assignConversation
);

router.post(
  "/:conversationId/takeover",
  authenticate,
  requireAction("chat.takeover", {
    resource: (req) => ({
      tenant_id: req.user!.tenant_id,
      type: "conversation",
      id: req.params.conversationId,
    }),
    context: (req) => ({
      ai_confidence: Number(req.body?.ai_confidence ?? req.query.ai_confidence ?? 1),
    }),
  }),
  takeoverConversation
);

export default router;
