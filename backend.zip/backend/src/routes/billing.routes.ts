import { Router } from "express";
import { refundInvoice } from "../controllers/billing.controller.js";
import { authenticate } from "../middlewares/auth.guard.js";
import { requireAction } from "../middlewares/requireAction.js";

const router = Router();

router.post(
  "/invoices/:id/refund",
  authenticate,
  requireAction("billing.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "invoice", id: req.params.id }),
    context: (req) => ({
      amount: Number(req.body?.amount ?? 0),
      plan: { refund_limit: Number(req.body?.plan?.refund_limit ?? 5000) },
    }),
  }),
  refundInvoice
);

export default router;
