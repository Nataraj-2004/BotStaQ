import { Router } from "express";
import analyticsRoutes from "./analytics.routes.js";
import authRoutes from "./auth.routes.js";
import billingRoutes from "./billing.routes.js";
import conversationsRoutes from "./conversations.routes.js";
import dashboardRoutes from "./dashboard.routes.js";
import kbRoutes from "./kb.routes.js";
import leadsRoutes from "./leads.routes.js";

const router = Router();

router.get("/health", (_req, res) => {
  res.json({ status: "ok" });
});

router.use("/auth", authRoutes);
router.use("/conversations", conversationsRoutes);
router.use("/dashboard", dashboardRoutes);
router.use("/kb", kbRoutes);
router.use("/analytics", analyticsRoutes);
router.use("/billing", billingRoutes);
router.use("/leads", leadsRoutes);

export default router;
