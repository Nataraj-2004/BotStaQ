import { Router } from "express";
import { exportAnalytics, getAnalyticsOverview } from "../controllers/analytics.controller.js";
import { authenticate } from "../middlewares/auth.guard.js";
import { requireAction } from "../middlewares/requireAction.js";

const router = Router();

router.get(
  "/overview",
  authenticate,
  requireAction("analytics.read", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "analytics" }),
  }),
  getAnalyticsOverview
);

router.post(
  "/export",
  authenticate,
  requireAction("analytics.export", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "analytics" }),
    context: (req) => ({
      subscription_plan: req.body?.subscription_plan ?? req.query.plan,
      mfa_passed: Boolean(req.body?.mfa_passed ?? req.query.mfa_passed),
    }),
  }),
  exportAnalytics
);

export default router;
