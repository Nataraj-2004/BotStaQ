import { Router } from "express";
import {
  createDocument,
  createFaq,
  createProduct,
  createRule,
  listKnowledgeBase,
} from "../controllers/kb.controller.js";
import { authenticate } from "../middlewares/auth.guard.js";
import { requireAction } from "../middlewares/requireAction.js";

const router = Router();

router.get(
  "/",
  authenticate,
  requireAction("kb.read", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "knowledge_base" }),
  }),
  listKnowledgeBase
);

router.post(
  "/docs",
  authenticate,
  requireAction("kb.write", {
    resource: (req) => ({
      tenant_id: req.user!.tenant_id,
      type: "kb_doc",
      confidentiality: req.body?.confidentiality ?? "standard",
      id: req.body?.id,
    }),
  }),
  createDocument
);

router.post(
  "/faqs",
  authenticate,
  requireAction("kb.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "knowledge_base_faq" }),
  }),
  createFaq
);

router.post(
  "/rules",
  authenticate,
  requireAction("kb.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "knowledge_base_rule" }),
  }),
  createRule
);

router.post(
  "/products",
  authenticate,
  requireAction("kb.write", {
    resource: (req) => ({ tenant_id: req.user!.tenant_id, type: "knowledge_base_product" }),
  }),
  createProduct
);

export default router;
