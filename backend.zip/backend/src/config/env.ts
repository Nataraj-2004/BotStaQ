import { config } from "dotenv";
import { z } from "zod";

config();

const envSchema = z.object({
  PORT: z.string().default("4000"),
  JWT_SECRET: z.string().default("dev-secret"),
  MONGO_URI: z.string().default("mongodb://127.0.0.1:27017/botstaq"),
  LOG_LEVEL: z.string().default("info"),
});

export const env = envSchema.parse(process.env);
