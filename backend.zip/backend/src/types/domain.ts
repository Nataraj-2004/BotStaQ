export type Channel = "web" | "whatsapp" | "email";

export interface Message {
  id: string;
  conversationId: string;
  sender: "user" | "agent" | "bot";
  text: string;
  createdAt: string;
}

export interface Conversation {
  id: string;
  subject: string;
  channel: Channel;
  status: "open" | "pending" | "resolved";
  assignee?: string;
  leadId?: string;
  lastMessageAt: string;
  createdAt: string;
}

export interface Lead {
  id: string;
  name: string;
  email?: string;
  stage: "new" | "qualified" | "proposal" | "won" | "lost";
  source?: string;
  score?: number;
  owner?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AnalyticsOverview {
  range: string;
  kpis: {
    leads: number;
    conversionRate: number;
    meetings: number;
    mrr: number;
  };
  channels: Array<{ channel: Channel; conversations: number; revenue: number }>;
}
