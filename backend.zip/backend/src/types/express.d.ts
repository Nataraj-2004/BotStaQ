import "express";
import { ResourceContext, SubjectContext } from "./auth";

declare module "express-serve-static-core" {
  interface Request {
    user?: SubjectContext;
    resource?: ResourceContext;
  }
}

export {};
