export interface SubjectContext {
  id: string;
  tenant_id: string;
  roles: string[];
  direct_permissions?: string[];
  attributes?: Record<string, unknown>;
}

export interface ResourceContext {
  tenant_id: string;
  type?: string;
  id?: string;
  owner_id?: string;
  confidentiality?: "standard" | "restricted" | string;
  [key: string]: unknown;
}

export interface ActionContext {
  action: string;
  ai_confidence?: number;
  subscription_plan?: string;
  mfa_passed?: boolean;
  plan?: { refund_limit?: number };
  amount?: number;
  [key: string]: unknown;
}

export interface RelationshipEdge {
  relation: string;
  subject: { type: string; id: string };
  object: { type: string; id: string };
}

export interface RelationshipGrant {
  action: string;
  subject: { type: string; id: string };
  object: { type: string; id: string };
}
