import { NextFunction, Request, Response } from "express";
import { AuthenticationError, AuthorizationError } from "../utils/errors.js";

export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  if (err instanceof AuthorizationError || err instanceof AuthenticationError) {
    res.status(err.status).json({ error: err.message });
    return;
  }

  console.error("Unexpected error", err);
  res.status(500).json({ error: "Internal server error" });
}
