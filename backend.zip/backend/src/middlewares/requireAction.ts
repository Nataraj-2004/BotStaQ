import { NextFunction, Request, Response } from "express";
import { authorize } from "../services/authz.js";
import { AuthenticationError } from "../utils/errors.js";
import { ActionContext, ResourceContext } from "../types/auth.js";

type Builder<T> = (req: Request) => T;

interface RequireOptions {
  resource?: Builder<ResourceContext>;
  context?: Builder<Partial<ActionContext>>;
}

export function requireAction(action: string, options: RequireOptions = {}) {
  return function guard(req: Request, _res: Response, next: NextFunction): void {
    if (!req.user) {
      throw new AuthenticationError("User context missing");
    }

    const resource = options.resource?.(req) ?? { tenant_id: req.user.tenant_id };
    const context = options.context?.(req) ?? {};

    authorize(req.user, resource, action, context);
    next();
  };
}
