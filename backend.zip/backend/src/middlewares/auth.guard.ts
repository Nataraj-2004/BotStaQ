import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/env.js";
import { AuthenticationError } from "../utils/errors.js";
import { SubjectContext } from "../types/auth.js";

interface TokenPayload extends SubjectContext {
  sub: string;
  exp?: number;
}

export function authenticate(req: Request, _res: Response, next: NextFunction): void {
  const header = req.headers["authorization"];

  if (!header || Array.isArray(header)) {
    throw new AuthenticationError("Authorization header missing");
  }

  const [scheme, token] = header.split(" ");

  if (scheme?.toLowerCase() !== "bearer" || !token) {
    throw new AuthenticationError("Invalid authorization header format");
  }

  try {
    const decoded = jwt.verify(token, env.JWT_SECRET) as TokenPayload;
    const subject: SubjectContext = {
      id: decoded.id ?? decoded.sub,
      tenant_id: decoded.tenant_id,
      roles: decoded.roles,
      direct_permissions: decoded.direct_permissions,
      attributes: decoded.attributes,
    };
    req.user = subject;
    next();
  } catch (error) {
    throw new AuthenticationError("Invalid or expired token");
  }
}
