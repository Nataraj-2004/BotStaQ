import { randomUUID } from "node:crypto";
import { AnalyticsOverview, Conversation, Lead, Message } from "../types/domain.js";

const now = () => new Date().toISOString();

const conversations: Conversation[] = [
  {
    id: "conv-1",
    subject: "Pricing question",
    channel: "web",
    status: "open",
    assignee: "agent-1",
    leadId: "lead-1",
    lastMessageAt: now(),
    createdAt: now(),
  },
  {
    id: "conv-2",
    subject: "Integration help",
    channel: "whatsapp",
    status: "pending",
    assignee: "agent-2",
    leadId: "lead-2",
    lastMessageAt: now(),
    createdAt: now(),
  },
];

const messages: Message[] = [
  {
    id: "msg-1",
    conversationId: "conv-1",
    sender: "user",
    text: "How much does the Pro plan cost?",
    createdAt: now(),
  },
  {
    id: "msg-2",
    conversationId: "conv-1",
    sender: "bot",
    text: "Our Pro plan starts at $249/mo.",
    createdAt: now(),
  },
  {
    id: "msg-3",
    conversationId: "conv-2",
    sender: "user",
    text: "Can you help me connect HubSpot?",
    createdAt: now(),
  },
];

const leads: Lead[] = [
  {
    id: "lead-1",
    name: "Scarlett Rivera",
    email: "scarlett@example.com",
    stage: "qualified",
    source: "chat",
    score: 82,
    owner: "agent-1",
    createdAt: now(),
    updatedAt: now(),
  },
  {
    id: "lead-2",
    name: "Jordan Lee",
    email: "jordan@example.com",
    stage: "new",
    source: "campaign",
    score: 60,
    owner: "agent-2",
    createdAt: now(),
    updatedAt: now(),
  },
];

const knowledgeBaseDocs = [
  { id: "doc-1", title: "Pricing FAQ", category: "Docs" },
  { id: "doc-2", title: "Integrations Guide", category: "Docs" },
  { id: "doc-3", title: "Playbook Best Practices", category: "Docs" },
];

const faqs = [
  { id: "faq-1", question: "How do I connect HubSpot?", answer: "Visit integrations tab and click connect." },
  { id: "faq-2", question: "Do you support WhatsApp?", answer: "Yes, via official WhatsApp Business API." },
];

const automationRules = [
  { id: "rule-1", name: "Escalate low confidence", trigger: "ai_confidence < 0.4" },
  { id: "rule-2", name: "Assign VIP leads", trigger: "lead.score > 80" },
];

const kbProducts = [
  { id: "prod-1", name: "BotStaQ Pro", price: 249, plan: "Pro" },
  { id: "prod-2", name: "BotStaQ Enterprise", price: 599, plan: "Enterprise" },
];

export const db = {
  conversations,
  messages,
  leads,
  knowledgeBaseDocs,
  faqs,
  automationRules,
  kbProducts,
  getAnalytics(range: string): AnalyticsOverview {
    return {
      range,
      kpis: {
        leads: leads.length,
        conversionRate: 28,
        meetings: 12,
        mrr: 18400,
      },
      channels: [
        { channel: "web", conversations: 54, revenue: 9200 },
        { channel: "whatsapp", conversations: 37, revenue: 6800 },
        { channel: "email", conversations: 21, revenue: 3400 },
      ],
    };
  },
  addMessage(conversationId: string, sender: Message["sender"], text: string): Message {
    const msg: Message = {
      id: randomUUID(),
      conversationId,
      sender,
      text,
      createdAt: now(),
    };
    messages.push(msg);
    const conv = conversations.find((item) => item.id === conversationId);
    if (conv) {
      conv.lastMessageAt = msg.createdAt;
    }
    return msg;
  },
  addLead(data: Partial<Lead>): Lead {
    const lead: Lead = {
      id: randomUUID(),
      name: data.name ?? "Unnamed Lead",
      email: data.email,
      stage: data.stage ?? "new",
      source: data.source ?? "chat",
      score: data.score ?? 50,
      owner: data.owner,
      createdAt: now(),
      updatedAt: now(),
    };
    leads.push(lead);
    return lead;
  },
  updateLead(id: string, data: Partial<Lead>): Lead | undefined {
    const idx = leads.findIndex((lead) => lead.id === id);
    if (idx === -1) return undefined;
    leads[idx] = {
      ...leads[idx],
      ...data,
      updatedAt: now(),
    };
    return leads[idx];
  },
  getDashboardSummary() {
    const byStatus = conversations.reduce(
      (acc, conversation) => {
        acc[conversation.status] = (acc[conversation.status] ?? 0) + 1;
        return acc;
      },
      {} as Record<Conversation["status"], number>
    );

    const leadTotals = leads.reduce(
      (acc, lead) => {
        acc[lead.stage] = (acc[lead.stage] ?? 0) + 1;
        return acc;
      },
      {} as Record<Lead["stage"], number>
    );

    return {
      conversations: {
        total: conversations.length,
        open: byStatus.open ?? 0,
        pending: byStatus.pending ?? 0,
        resolved: byStatus.resolved ?? 0,
      },
      leads: {
        total: leads.length,
        new: leadTotals.new ?? 0,
        qualified: leadTotals.qualified ?? 0,
        proposal: leadTotals.proposal ?? 0,
        won: leadTotals.won ?? 0,
        lost: leadTotals.lost ?? 0,
      },
      website: {
        visitors: 1824,
        conversionRate: 3.6,
        bounceRate: 48,
      },
      automations: {
        active: 12,
        paused: 3,
      },
    };
  },
  listKnowledgeBase() {
    return {
      docs: knowledgeBaseDocs,
      faqs,
      rules: automationRules,
      products: kbProducts,
    };
  },
  addKnowledgeDocument(title: string) {
    const doc = { id: randomUUID(), title, category: "Docs" };
    knowledgeBaseDocs.push(doc);
    return doc;
  },
  addFaq(question: string, answer: string) {
    const faq = { id: randomUUID(), question, answer };
    faqs.push(faq);
    return faq;
  },
  addRule(name: string, trigger: string) {
    const rule = { id: randomUUID(), name, trigger };
    automationRules.push(rule);
    return rule;
  },
  addProduct(name: string, price: number, plan: string) {
    const product = { id: randomUUID(), name, price, plan };
    kbProducts.push(product);
    return product;
  },
};
