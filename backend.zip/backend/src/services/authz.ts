import fs from "node:fs";
import path from "node:path";
import { AuthorizationError } from "../utils/errors.js";
import {
  ActionContext,
  RelationshipEdge,
  RelationshipGrant,
  ResourceContext,
  SubjectContext,
} from "../types/auth.js";

type Policy = {
  id: string;
  applies_to: string;
  logic: unknown;
};

type PermissionCatalog = {
  version: number;
  permissions: { name: string; desc?: string }[];
};

type RoleCatalog = {
  version: number;
  roles: { name: string; scope: string; permissions: string[] }[];
};

type PolicyCatalog = {
  version: number;
  policies: Policy[];
};

type RelationshipCatalog = {
  version: number;
  relationships: RelationshipEdge[];
  grants: RelationshipGrant[];
};

const AUTH_DIR = path.resolve(process.cwd(), "auth");

function readJSON<T>(file: string): T {
  const payload = fs.readFileSync(path.join(AUTH_DIR, file), "utf-8");
  return JSON.parse(payload) as T;
}

const PERMISSIONS = new Set(
  readJSON<PermissionCatalog>("permissions.json").permissions.map((p) => p.name)
);

const ROLES = new Map(
  readJSON<RoleCatalog>("roles.json").roles.map((role) => [role.name, new Set(role.permissions)])
);

const POLICIES = readJSON<PolicyCatalog>("policies.json").policies;

const RELATION_DATA = readJSON<RelationshipCatalog>("relationships.json");

const ACTIONS_WITH_REL_CHECK = new Set(["kb.write", "dashboard.view"]);

const membershipIndex = new Map<string, Set<string>>();
const ownershipIndex = new Map<string, Set<string>>();
const adminIndex = new Map<string, Set<string>>();

for (const edge of RELATION_DATA.relationships) {
  if (edge.relation === "member-of" && edge.subject.type === "user") {
    const list = membershipIndex.get(edge.subject.id) ?? new Set<string>();
    list.add(edge.object.id);
    membershipIndex.set(edge.subject.id, list);
  }
  if (edge.relation === "owner-of" && edge.subject.type === "user") {
    const list = ownershipIndex.get(edge.subject.id) ?? new Set<string>();
    list.add(edge.object.id);
    ownershipIndex.set(edge.subject.id, list);
  }
  if (edge.relation === "admin-of" && edge.subject.type === "user") {
    const list = adminIndex.get(edge.subject.id) ?? new Set<string>();
    list.add(edge.object.id);
    adminIndex.set(edge.subject.id, list);
  }
}

export function effectivePermissions(subject: SubjectContext): Set<string> {
  const effective = new Set<string>();
  for (const perm of subject.direct_permissions ?? []) {
    effective.add(perm);
  }
  for (const role of subject.roles) {
    const grants = ROLES.get(role);
    if (!grants) continue;
    for (const perm of grants) {
      effective.add(perm);
    }
  }
  return effective;
}

export function authorize(
  subject: SubjectContext,
  resource: ResourceContext,
  action: string,
  context: Omit<ActionContext, "action"> = {}
): void {
  const normalizedContext: ActionContext = { action, ...context };

  if (!PERMISSIONS.has(action) && action !== "dashboard.view") {
    throw new AuthorizationError(`Unknown action: ${action}`, 404);
  }

  const eff = effectivePermissions(subject);

  if (!eff.has(action) && action !== "dashboard.view") {
    throw new AuthorizationError("Permission denied");
  }

  if (!abacAllows(action, subject, resource, normalizedContext)) {
    throw new AuthorizationError("ABAC policy denied access");
  }

  if (!rebacAllows(action, subject, resource)) {
    throw new AuthorizationError("ReBAC denied access");
  }
}

function abacAllows(
  action: string,
  subject: SubjectContext,
  resource: ResourceContext,
  context: ActionContext
): boolean {
  for (const policy of POLICIES) {
    if (policy.applies_to !== "*" && policy.applies_to !== action) {
      continue;
    }
    if (!evaluate(policy.logic, { subject, resource, context, action })) {
      return false;
    }
  }
  return true;
}

function rebacAllows(
  action: string,
  subject: SubjectContext,
  resource: ResourceContext
): boolean {
  if (!ACTIONS_WITH_REL_CHECK.has(action)) {
    return true;
  }

  if (subject.roles.includes("super_admin")) {
    return true;
  }

  if (
    subject.roles.includes("company_admin") &&
    resource.tenant_id === subject.tenant_id
  ) {
    return true;
  }

  const adminTenants = adminIndex.get(subject.id);
  if (adminTenants && resource.tenant_id && adminTenants.has(resource.tenant_id)) {
    return true;
  }

  if (resource.id) {
    const owns = ownershipIndex.get(subject.id);
    if (owns && owns.has(resource.id)) {
      return true;
    }
  }

  const memberships = membershipIndex.get(subject.id);
  if (!memberships) {
    return false;
  }

  for (const grant of RELATION_DATA.grants) {
    if (grant.action !== action) continue;
    if (resource.id && grant.object.id !== resource.id) continue;
    if (!resource.id && grant.object.type && resource.type && grant.object.type !== resource.type) {
      continue;
    }
    if (grant.subject.type === "team" && memberships.has(grant.subject.id)) {
      return true;
    }
  }

  return false;
}

type LogicContext = {
  subject: SubjectContext;
  resource: ResourceContext;
  context: ActionContext;
  action: string;
};

type LogicExpr =
  | { all: LogicExpr[] }
  | { any: LogicExpr[] }
  | { not: LogicExpr }
  | { "==": [unknown, unknown] }
  | { "<=": [unknown, unknown] }
  | { "<": [unknown, unknown] }
  | { in: [unknown, unknown] }
  | { var: string }
  | unknown;

function evaluate(expr: unknown, ctx: LogicContext): boolean {
  if (typeof expr !== "object" || expr === null) {
    return toBoolean(expr);
  }

  if ("all" in (expr as Record<string, unknown>)) {
    const list = (expr as { all: LogicExpr[] }).all;
    return list.every((item) => evaluate(item, ctx));
  }

  if ("any" in (expr as Record<string, unknown>)) {
    const list = (expr as { any: LogicExpr[] }).any;
    return list.some((item) => evaluate(item, ctx));
  }

  if ("not" in (expr as Record<string, unknown>)) {
    return !evaluate((expr as { not: LogicExpr }).not, ctx);
  }

  if ("==" in (expr as Record<string, unknown>)) {
    const [left, right] = (expr as { "==": [unknown, unknown] })["=="];
    return resolve(left, ctx) === resolve(right, ctx);
  }

  if ("<=" in (expr as Record<string, unknown>)) {
    const [left, right] = (expr as { "<=": [unknown, unknown] })["<="];
    return Number(resolve(left, ctx)) <= Number(resolve(right, ctx));
  }

  if ("<" in (expr as Record<string, unknown>)) {
    const [left, right] = (expr as { "<": [unknown, unknown] })["<"];
    return Number(resolve(left, ctx)) < Number(resolve(right, ctx));
  }

  if ("in" in (expr as Record<string, unknown>)) {
    const [valueExpr, collectionExpr] = (expr as { in: [unknown, unknown] }).in;
    const value = resolve(valueExpr, ctx);
    const collection = resolve(collectionExpr, ctx);
    if (Array.isArray(collection)) {
      return collection.includes(value);
    }
    if (typeof collection === "string") {
      return collection.includes(String(value));
    }
    return false;
  }

  if ("var" in (expr as Record<string, unknown>)) {
    return Boolean(resolve(expr, ctx));
  }

  return toBoolean(expr);
}

function resolve(value: unknown, ctx: LogicContext): unknown {
  if (typeof value === "object" && value !== null && "var" in (value as Record<string, unknown>)) {
    const path = ((value as { var: string }).var).split(".");
    let current: any = ctx;
    for (const key of path) {
      if (current == null) return undefined;
      current = current[key];
    }
    return current;
  }
  return value;
}

function toBoolean(input: unknown): boolean {
  if (Array.isArray(input)) {
    return input.length > 0;
  }
  return Boolean(input);
}
