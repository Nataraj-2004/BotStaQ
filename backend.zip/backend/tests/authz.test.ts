import { describe, expect, test } from "vitest";
import { authorize } from "../src/services/authz.js";
import { AuthorizationError } from "../src/utils/errors.js";

const baseAgent = {
  id: "u_agent",
  tenant_id: "t_demo",
  roles: ["agent"],
};

const companyAdmin = {
  id: "u_admin",
  tenant_id: "t_demo",
  roles: ["company_admin"],
};

describe("authorize", () => {
  test("allows agent takeover when AI confidence low", () => {
    expect(() =>
      authorize(
        baseAgent,
        { tenant_id: "t_demo", id: "conv_1", type: "conversation" },
        "chat.takeover",
        { ai_confidence: 0.4 }
      )
    ).not.toThrow();
  });

  test("blocks agent takeover when AI confidence high", () => {
    expect(() =>
      authorize(
        baseAgent,
        { tenant_id: "t_demo", id: "conv_2", type: "conversation" },
        "chat.takeover",
        { ai_confidence: 0.9 }
      )
    ).toThrow(AuthorizationError);
  });

  test("company admin passes analytics export policy", () => {
    expect(() =>
      authorize(
        companyAdmin,
        { tenant_id: "t_demo", type: "analytics" },
        "analytics.export",
        { subscription_plan: "PRO", mfa_passed: true }
      )
    ).not.toThrow();
  });

  test("company admin blocked if plan missing for analytics export", () => {
    expect(() =>
      authorize(
        companyAdmin,
        { tenant_id: "t_demo", type: "analytics" },
        "analytics.export",
        { subscription_plan: "BASIC", mfa_passed: true }
      )
    ).toThrow(AuthorizationError);
  });

  test("billing write fails when amount exceeds limit for finance manager", () => {
    const financeManager = {
      id: "u_fin",
      tenant_id: "t_demo",
      roles: ["finance_manager"],
    };

    expect(() =>
      authorize(
        financeManager,
        { tenant_id: "t_demo", type: "invoice", id: "inv_1" },
        "billing.write",
        { amount: 10000, plan: { refund_limit: 5000 } }
      )
    ).toThrow(AuthorizationError);
  });
});
